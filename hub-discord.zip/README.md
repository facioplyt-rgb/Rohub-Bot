# Hub Discord — bot i poradnik uruchomienia

Wersja 1.0 • przygotowano 18 października 2026 • Python 3.12 • discord.py 2.7.1 • SQLite.

## 1. Co dostajesz

Jeden bot do huba modeli, map, skryptów, zestawów i usług związanych z Roblox Studio. Obsługa odbywa się na Discordzie. Płatność i przekazanie produktu kupujący ustala ze sprzedawcą na DM.

W paczce działają następujące moduły:

- Dodawanie struktury serwera: 9 kategorii, 27 kanałów tekstowych i forum, 8 ról oraz panele z przyciskami.
- Akceptacja regulaminu i dostęp do wystawiania ofert przez rolę sprzedawcy.
- Osobne fora oficjalne i nieoficjalne: modele, mapy, skrypty, zestawy, usługi.
- Formularze ofert, cena z walutą, opis, podgląd, autorstwo, licencja i wymagania.
- Ręczne sprawdzanie ofert oficjalnych z zakresem kontroli i oznaczeniem wersji.
- Wstrzymywanie i edytowanie ofert. Zmiana oficjalnej oferty wymaga ponownego sprawdzenia.
- Przycisk Kup tworzący prywatny kanał i zachowujący warunki oferty z chwili otwarcia.
- Oznaczenie dostawy, odbioru, anulowanie przed dostawą i archiwum.
- Prywatne obrazy dowodów zakupu i niezależna decyzja opiekuna.
- Oceny 1–5, potwierdzenie dostawy i zgodności z opisem, komentarze oraz historia zmian.
- Profil sprzedawcy, liczba potwierdzonych zakupów, średnia i liczba różnych oceniających.
- Ranking po uzyskaniu co najmniej trzech różnych oceniających.
- Spory, zgłoszenia ofert, wnioski o rolę sprzedawcy i odwołania.
- Wyszukiwanie po tekście, kategorii, sprzedawcy i statusie oficjalnym.
- Obserwowanie konkretnej oferty i powiadomienia o opublikowanych aktualizacjach na DM.
- Ostrzeżenia, czasowe wyciszenia, ograniczone czyszczenie kanałów społeczności.
- Logi, statystyki, diagnostyka, kopie bazy i eksport tekstowej historii.
- Trwałe przyciski, SQLite i ochrona przed podwójnym kliknięciem Kup.

**Zakres tej wersji:** nie zawiera automatycznych płatności, automatycznego wydawania plików, osobnej strony internetowej, wyszukiwania po liczbowym zakresie cen, obserwowania całego sprzedawcy, kuponów ani automatycznego wygaszania promocji. Zestaw produktów wystawiasz jako jedną ofertę; usługę lub wykonanie na zamówienie jako ofertę w kategorii usługi. Wersja nie ma osobnej giełdy zapytań kupujących ani automatycznego wykrywania plagiatu i złośliwego kodu.

**Status sprawdzenia:** kod sprawdzono lokalnie testami bazy, uprawnień aplikacyjnych i zgodności z biblioteką. Nie użyto tokenu, konta ani serwera użytkownika. Utworzenie prawdziwych kanałów, instalacja na hostingu i test z kilkoma osobami pozostają do wykonania według punktu 11.

## 2. Co musisz mieć

1. Konto Discord i serwer, którego jesteś właścicielem.
2. Dostęp do przeglądarki oraz możliwość pobrania i wgrania ZIP.
3. Konto na [Bot-Hosting.net](https://bot-hosting.net/).
4. Token **bota**, identyfikator serwera i włączone Community / Społeczność.
5. Drugą niezależną osobę do sprawdzania Twoich własnych ofert i zakupów, jeśli sam będziesz stroną transakcji.

Możesz przejść konfigurację z telefonu. Portale otwieraj w Chrome/Safari; jeśli brakuje ustawień lub menu, włącz „Witryna na komputer” / „Wersja na komputer”. Sam bot działa na hostingu, a nie w aplikacji Discord na telefonie.

**Najpierw użyj osobnego serwera testowego.** Próbne opinie i fikcyjne dowody nie powinny trafiać do reputacji produkcyjnego huba.

## 3. Utworzenie bota Discord

1. Otwórz [Discord Developer Portal](https://discord.com/developers/applications), zaloguj się i wybierz **New Application**.
2. Nadaj aplikacji nazwę. W zakładce **Bot** ustaw nazwę oraz ikonę bota.
3. W sekcji **Privileged Gateway Intents** włącz **Message Content Intent**. Ta paczka korzysta z niego przy eksporcie historii wiadomości. **Server Members Intent** i **Presence Intent** pozostaw wyłączone.
4. W części tokenu wybierz **Reset Token** i skopiuj token do menedżera haseł. Wkleisz go później wyłącznie w sekret hostingu.
5. Pole **Interactions Endpoint URL** pozostaw puste. Ta paczka łączy się przez Gateway, nie przez endpoint HTTP. Nie potrzebuje Public Key, ngrok ani otwierania portu WWW.
6. W **Installation** wybierz kontekst **Guild Install**. W ustawieniach instalacji dodaj zakresy `bot` oraz `applications.commands`.
7. Nadaj botowi uprawnienia z tabeli poniżej. Skopiuj link instalacyjny, otwórz go i wybierz swój serwer.

[Oficjalna instrukcja Discorda — aplikacja, token i instalacja](https://docs.discord.com/developers/quick-start/getting-started).

| Uprawnienie po angielsku | Do czego służy w tej paczce |
|---|---|
| View Channels | Dostęp do kanałów |
| Send Messages | Panele i komunikaty |
| Read Message History | Odczyt ofert i eksport historii |
| Embed Links | Karty produktów i opinii |
| Attach Files | Dowody, kopie i eksporty |
| Manage Channels | Tworzenie i archiwizowanie kanałów |
| Manage Roles | Nadawanie ról i ustawianie dostępu do kanałów |
| Manage Messages | Czyszczenie kanałów społeczności |
| Manage Threads | Obsługa i aktualizacja postów ofert |
| Create Public Threads | Tworzenie postów ofert |
| Send Messages in Threads | Wiadomości w postach |
| Moderate Members | Czasowe wyciszanie |

**Administrator nie jest wymagany.** Gdy portal pozwala wprowadzić liczbę uprawnień, wartość tej paczki wynosi `1426197703696`. Jeśli korzystasz z OAuth2 URL Generator, zaznacz zakresy `bot` i `applications.commands` oraz te same uprawnienia. Ostateczny zestaw można sprawdzić przez `python -c "from hub.setup import bot_permissions; print(bot_permissions().value)"` w katalogu projektu.

## 4. Przygotowanie serwera i skopiowanie GUILD_ID

1. Utwórz serwer testowy w Discordzie. Ustaw jego nazwę i ikonę.
2. Wejdź w **Ustawienia serwera → Społeczność / Community → Włącz / Enable** i przejdź kreator. Wskaż wymagane kanały regulaminu oraz aktualizacji społeczności. Mogą być na razie tymczasowe.
3. Włącz **Tryb dewelopera / Developer Mode** w ustawieniach użytkownika Discorda, w części zaawansowanej.
4. W menu serwera wybierz **Kopiuj ID serwera / Copy Server ID**. To liczba, a nie nazwa ani link zaproszenia.
5. Zapisz ją jako `GUILD_ID`.

Po uruchomieniu /konfiguruj możesz wskazać nowy kanał regulaminu huba jako kanał zasad Community. Kanał aktualizacji dla moderatorów pozostaw właściwy dla komunikatów Discorda.

Źródła: [włączenie Community](https://support.discord.com/hc/en-us/articles/360047132851-Enabling-Your-Community-Server), [kopiowanie ID](https://support.discord.com/hc/pl/articles/206346498-Gdzie-znajd%C4%99-ID-u%C5%BCytkownika-serwera-wiadomo%C5%9Bci), [fora wymagają Community](https://support.discord.com/hc/en-us/articles/6208479917079-Forum-Channels-FAQ).

## 5. Darmowy hosting — konfiguracja z telefonu

Według oferty sprawdzonej 18.10.2026 Bot-Hosting.net daje bez karty 256 MB RAM, 512 MB miejsca i jedną aplikację. Darmowy plan wymaga ręcznego odnowienia w panelu co 4 dni. To ograniczony plan startowy; zużycie pełnego bota trzeba zmierzyć przy rzeczywistym ruchu. Nie ma tu obietnicy nieprzerwanej dostępności.

1. Otwórz [Bot-Hosting.net](https://bot-hosting.net/) i utwórz konto.
2. Utwórz **Deployment / Application** w planie **Free**. Wybierz **Python**, najlepiej **3.12**.
3. Jako źródło wybierz archiwum i wgraj `hub-discord.zip`. Jeśli aplikacja już istnieje, skorzystaj z **Files → Upload** i rozpakuj ZIP.
4. Po rozpakowaniu `main.py`, `requirements.txt` i folder `hub` muszą być razem w katalogu głównym aplikacji. ZIP nie wymaga dodatkowego folderu nadrzędnego.
5. W **Startup** ustaw **Entry File / STARTUP_FILE** na `main.py`. Jeżeli panel pyta o komendę, wpisz `python main.py`.
6. Zależności mają zostać zainstalowane z `requirements.txt`. Nie wklejaj tam polecenia pip; plik jest już gotowy.
7. W ustawieniach środowiska **Environment / Variables / Secrets** dodaj poniższe wartości. Jeśli nie ma takiej zakładki, użyj opisanej niżej metody z `.env`.
8. Uruchom aplikację i sprawdź konsolę. Pierwszy start może obejmować instalowanie bibliotek. Szukaj wpisu **HUB GOTOWY**.

| Nazwa zmiennej | Wartość | Sekret |
|---|---|---|
| `DISCORD_TOKEN` | Token Twojego bota z Developer Portal | Tak |
| `GUILD_ID` | ID Twojego serwera Discord | Nie musi być tajne |

Wklejaj same wartości, bez `DISCORD_TOKEN=` w polu wartości, bez znaków `< >` i bez dopisywania `Bot ` przed tokenem.

**Wariant .env:** w prywatnym edytorze plików hostingu utwórz `.env`, przepisz strukturę z `.env.example` i zastąp wartości. Nie publikuj ani nie wysyłaj tego pliku. Nie trzeba instalować python-dotenv. Nazwa musi brzmieć `.env`, a nie `.env.txt`.

Nie konfiguruj UptimeRobot ani pętli pingowania. Ta aplikacja nie jest serwerem WWW. Sprawdzaj RAM i miejsce w panelu. Pliki produktów sprzedawcy przekazują na DM — nie są przechowywane na dysku hostingu bota.

Źródła: [plan Free](https://bot-hosting.net/pricing), [tworzenie aplikacji](https://bot-hosting.net/docs/guides/create-a-deployment), [wgrywanie plików i Startup](https://bot-hosting.net/docs/guides/set-up-a-deployment), [sekrety środowiska](https://bot-hosting.net/docs/pages-and-resources/developer-api-connected-apps-and-mcp). Nazwy menu mogą różnić się zależnie od wersji panelu.

## 6. Automatyczne utworzenie huba

Po pojawieniu się bota online:

1. W ustawieniach ról Discorda przenieś **rolę samego bota wysoko**, poniżej zaufanych ról właściciela. Nie nadawaj zwykłym użytkownikom uprawnień Administrator.
2. Jako właściciel serwera wpisz **/konfiguruj** i wybierz **potwierdz: True**.
3. Poczekaj na odpowiedź. Tworzenie kilkudziesięciu kanałów podlega limitom Discorda — nie klikaj ponownie co kilka sekund.
4. Sprawdź, czy rola bota znajduje się **nad wszystkimi utworzonymi rolami `Hub • ...`**. Jeśli nie, przenieś ją wyżej.
5. Użyj **/diagnostyka**. Jeśli pojawiają się brakujące kanały lub role, ponów /konfiguruj po usunięciu przyczyny.
6. Uzupełnij regulamin, opis serwera i nazwę huba przed publicznym otwarciem.

Komenda dodaje strukturę i zapisuje identyfikatory w bazie. Nie usuwa wcześniejszych kanałów ani ról. Ponowne wykonanie odtwarza brakujące elementy i odświeża własne panele; nie tworzy całej struktury drugi raz, jeśli baza pozostała zachowana.

**Uwaga o własnym regulaminie:** /panele i /konfiguruj odtwarzają treść paneli z kodu. Aby nie stracić własnej wersji, zmień tekst w `hub/client.py`, w metodzie `panels`, przed kolejnym odświeżeniem. Domyślne zasady są wzorem do uzupełnienia, a nie gotową analizą prawną działalności.

Struktura:

| Kategoria | Zawartość |
|---|---|
| START | Powitanie, regulamin, instrukcja, ogłoszenia |
| PANEL HUBA | Panel kupującego, panel sprzedawcy, wyszukiwarka, ranking |
| OFERTY OFICJALNE | Pięć forów: modele, mapy, skrypty, zestawy, usługi |
| OFERTY SPOŁECZNOŚCI | Te same pięć kategorii ofert niesprawdzonych |
| SPOŁECZNOŚĆ | Rozmowy, projekty, propozycje, opinie i pomoc |
| ZAMÓWIENIA | Prywatne kanały tworzone przy zakupie |
| ARCHIWUM | Zamknięte kanały, tylko do odczytu dla uczestników |
| ZGŁOSZENIA | Prywatna pomoc, zgłoszenia i wnioski sprzedawców |
| ADMINISTRACJA | Kolejka ofert, dowody, zgłoszenia, logi i stan bota |

Wersja 1.0 ogranicza kategorię do około 45 kanałów zamówień. Przy większej liczbie trzeba zamykać zakończone sprawy i po eksporcie usuwać stare kanały albo rozszerzyć obsługę dodatkowych kategorii. Same rekordy ofert i zamówień pozostają w bazie po usunięciu kanału.

## 7. Role personelu i sprzedawców

Nadajesz je przez **/rola osoba:... rola:... nadaj:True powod:...**. Odebranie: `nadaj:False`.

| Rola | Kto nadaje | Zastosowanie |
|---|---|---|
| Hub • Administrator | Właściciel | Zarządzanie botem, rolami zwykłych użytkowników i moderacją opinii |
| Hub • Moderator | Właściciel | Ostrzeżenia, wyciszenia i czyszczenie kanałów społeczności |
| Hub • Weryfikator | Właściciel | Kontrola produktów i decyzje o ofertach oficjalnych |
| Hub • Opiekun transakcji | Właściciel | Dowody zakupu, spory, pomoc, archiwizacja |
| Hub • Sprzedawca | Właściciel lub Hub Administrator | Wystawianie i prowadzenie sprzedaży |
| Hub • Sprawdzony sprzedawca | Właściciel lub Hub Administrator | Ręcznie przyznawane wyróżnienie; nie zastępuje roli sprzedawcy |
| Hub • Klient | Bot po akceptacji dowodu | Zakup potwierdzony przez opiekuna |
| Hub • Użytkownik | Przycisk akceptacji regulaminu | Zwykły dostęp do huba |

Przykład: nadaj znajomemu rolę **Opiekun transakcji**, a osobie publikującej produkty rolę **Sprzedawca**. Personel może mieć kilka ról, ale nie może zatwierdzać własnej oferty ani własnego dowodu. Zwykły sprzedawca nie otrzymuje praw do edytowania kanałów czy zarządzania serwerem.

**Prywatność dowodów:** dedykowany kanał widzą Hub Administrator, Opiekun transakcji i bot. Właściciel serwera oraz osoby z natywnym uprawnieniem Discord **Administrator** mogą omijać ograniczenia kanałów — nie da się przed nimi ukryć dowodów. Sprawdź również inne istniejące role i nadpisania uprawnień na swoim serwerze. [Dokumentacja uprawnień Discorda](https://docs.discord.com/developers/topics/permissions).

## 8. Publikowanie i sprawdzanie ofert

Sprzedawca akceptuje regulamin, wchodzi w panel sprzedawcy i wybiera **Wystaw ofertę**. Alternatywa: **/wystaw kategoria:mapy oficjalna:False**.

Formularz ma pięć pól: nazwa; opis; cena z walutą; pojedynczy link HTTPS do podglądu; autorstwo, licencja, wymagania i wsparcie. Ostatnie pole może wyglądać tak:

> Autor: moja nazwa. Mam prawo sprzedaży wszystkich elementów. Licencja: użycie w jednej własnej grze, bez odsprzedaży plików. Wymaga: podane zależności. Wsparcie: 14 dni na poprawę zgłoszonych błędów. Aktualizacje: zgodnie z opisem oferty.

Dopasuj warunki do faktycznego produktu. Opis może zawierać listę części zestawu lub zakres usługi. Cena jest tekstem, bot nie wykonuje przeliczeń walut i nie potwierdza przelewu.

- **Nieoficjalna:** po przesłaniu formularza jest publikowana w forum społeczności.
- **Oficjalna:** trafia do weryfikatora. Publikacja następuje po zatwierdzeniu.
- **Odrzucona:** sprzedawca poprawia ją przez /oferta → Edytuj. Powód trafia na DM, jeśli wiadomości są dostępne.

Pod produktem są: **Kup**, **Profil sprzedawcy**, **Obserwuj / przestań**, **Zgłoś ofertę**.

Przed zatwierdzeniem weryfikator sprawdza rzeczywisty produkt w odizolowanym projekcie, porównuje działanie z opisem, ocenia kod i materiały potwierdzające autorstwo. Bot zapisuje zakres sprawdzenia i wersję. Nie uruchamia przesłanych plików ani nie ogłasza, że automatycznie wykrył wszystkie zagrożenia.

Edycja oficjalnej oferty wstrzymuje sprzedaż i uruchamia ponowną kontrolę. Zakupy otwarte wcześniej zachowują oryginalną cenę, opis i warunki.

## 9. Zakup, dowód i opinia — dokładny przebieg

1. Kupujący klika **Kup**. Powstaje prywatny kanał z numerem zamówienia.
2. Kupujący i sprzedawca ustalają płatność oraz dostawę na DM. Bot nie odczytuje ich prywatnej rozmowy.
3. Sprzedawca klika **Produkt przekazany**. Kupujący potwierdza odbiór lub zgłasza problem.
4. Kupujący wpisuje **/dowod numer:42 plik:obraz opis:...**. Zastępuje 42 numerem swojego zamówienia.
5. Dowód może być plikiem PNG, JPG albo WEBP do 5 MB. Kupujący zasłania zbędne dane i opisuje powiązanie z konkretnym produktem.
6. Załącznik trafia do prywatnego kanału opiekunów. Wspólny kanał zamówienia nie otrzymuje kopii obrazu.
7. Opiekun wybiera **Zatwierdź dowód** lub **Odrzuć / uzupełnij** i wpisuje uzasadnienie. Nie może być stroną tego zamówienia.
8. Po akceptacji kupujący korzysta z **Wystaw / edytuj opinię** lub **/opinia zamowienie:42**.
9. Ocenia dostawę, zgodność z opisem i przyznaje od 1 do 5. Komentarz jest opcjonalny.
10. Niezależny opiekun archiwizuje zakończone zamówienie. Kanał pozostaje do odczytu. Opinia nie musi być pozytywna.

Nie trzeba potwierdzać udanej dostawy, żeby wystawić negatywną opinię: dowód może potwierdzać, że zakup nastąpił, a produkt nie został dostarczony. Otwarcie sporu nie blokuje takiej opinii po zatwierdzeniu dowodu. Użytkownik nie otrzymuje automatycznej oceny za milczenie.

Przy odrzuceniu dowodu uzasadnienie jest dostępne kupującemu na DM lub przez **/moje**. Może przesłać poprawiony obraz. Nowa wersja ma nowy numer; stara decyzja nie zastąpi nowszego dowodu.

Dowody graficzne z rozpatrzonych spraw są domyślnie usuwane z kanału po 30 dniach. Otwarty spór i dowód oczekujący na decyzję wstrzymują usunięcie. Decyzje i metadane w SQLite zostają; kopia bazy również zawiera dane prywatne. Usunięcie wiadomości nie daje gwarancji natychmiastowego usunięcia wszystkich kopii z infrastruktury Discorda lub urządzeń personelu.

## 10. Spory, opinie i moderacja

**Problem z zakupem:** kupujący lub sprzedawca wybiera Zgłoś problem, opisuje sprawę bez danych płatniczych. Bot zapisuje spór i zawiadamia personel. Opiekun zbiera wyjaśnienia; **/rozstrzygnij** wymaga uzasadnienia. Własnego sporu nie rozstrzygasz sam.

**Anulowanie:** kupujący może anulować przed dostawą i przed rozpoczęciem sprawdzania dowodu. Po dostawie, przy dowodzie lub sporze potrzebny jest niezależny opiekun. Sprzedawca będący członkiem personelu nie może użyć swoich uprawnień do zamknięcia własnej transakcji i zablokowania opinii.

**Odwołanie:** panel pomocy → Otwórz zgłoszenie. W sprawie decyzji opiekuna powinna wypowiedzieć się inna osoba. Bot zapewnia kanał i historię, a nie automatyczną ocenę prawdziwości zeznań.

**Opinie:** sprzedawca może odpowiedzieć przez /odpowiedz. Administrator może ukryć lub przywrócić opinię przez /ukryj_opinie z uzasadnieniem. Nie może sam ukryć opinii, której jest stroną. Edycja opinii zachowuje zapis wcześniejszej wersji w audycie.

**Odebranie sprzedaży:** /rola → Sprzedawca → nadaj:False. Aktywne oferty tej osoby są wstrzymywane. Wyróżnienie Sprawdzony sprzedawca również jest odbierane.

**Moderator:** /moderuj pozwala zapisać ostrzeżenie lub nadać timeout. Bot i moderator muszą mieć role wyżej niż osoba moderowana. /wyczysc działa tylko na kanałach rozmów, projektów i propozycji, żeby nie usuwać nim dowodów i historii zamówień.

## 11. Test przed otwarciem serwera

Wykonaj na serwerze testowym z różnymi kontami rzeczywistych uczestników. Wystarczy produkt opisany wyraźnie jako TEST, bez prawdziwej płatności. Takich wyników nie przenoś do produkcyjnej reputacji.

- [ ] Konto bez personelu nie widzi kategorii administracji ani cudzych zamówień.
- [ ] Weryfikator produktów bez roli opiekuna nie widzi kanału dowodów.
- [ ] Kupujący akceptuje regulamin i może korzystać z panelu.
- [ ] Sprzedawca wystawia ofertę nieoficjalną; post ma przyciski.
- [ ] Sprzedawca zgłasza oficjalną ofertę; niezależny weryfikator ją zatwierdza.
- [ ] Próba zatwierdzenia własnej oferty jest odrzucana.
- [ ] Dwukrotne kliknięcie Kup prowadzi do jednego aktywnego zamówienia.
- [ ] Kupujący, sprzedawca i opiekun widzą kanał; inny użytkownik go nie widzi.
- [ ] Opinia przed sprawdzeniem dowodu jest blokowana.
- [ ] Dowód wysłany przez /dowod jest widoczny tylko w odpowiednim kanale personelu.
- [ ] Opiekun odrzuca dowód, kupujący widzi uzasadnienie i wysyła poprawiony materiał.
- [ ] Inny opiekun akceptuje dowód; kupujący publikuje ocenę.
- [ ] Edycja opinii nie zwiększa liczby opinii; zmienia średnią.
- [ ] Negatywna opinia jest możliwa także przy zgłoszeniu braku dostawy.
- [ ] Sprzedawca nie może usunąć swojej negatywnej opinii.
- [ ] Otwarty spór blokuje archiwizację do czasu rozstrzygnięcia.
- [ ] Po restarcie stare przyciski działają, a zamówienia i oceny pozostają.
- [ ] /historia pobiera tekst rozmowy, a /backup daje plik właścicielowi.
- [ ] /diagnostyka nie zgłasza brakujących kanałów ani ról.
- [ ] RAM na hostingu mieści się w limicie także po kilku zakupach i wysłaniu dowodu.

Do testów lokalnych kodu, na komputerze:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m compileall -q main.py hub
```

Testy automatyczne nie wymagają tokenu ani dostępu do Discorda. Używają prawdziwego SQLite i zainstalowanej biblioteki discord.py; wybrane granice Discorda są sprawdzane bez sieci.

## 12. Wszystkie komendy

| Komenda | Zastosowanie |
|---|---|
| /pomoc | Skrócona instrukcja |
| /konfiguruj | Właściciel: utworzenie lub naprawa struktury |
| /panele | Właściciel: odświeżenie paneli |
| /rola | Nadawanie i odbieranie ról |
| /wystaw | Formularz nowej oferty |
| /oferta | Podgląd, edycja, wstrzymanie, wznowienie, zamknięcie, ponowna publikacja |
| /szukaj | Katalog z filtrami i stronami |
| /kup | Zakup na podstawie numeru oferty |
| /moje | Własne oferty, ostatnie zamówienia i uwagi do dowodów |
| /zamowienie | Podgląd i przyciski wybranego zamówienia |
| /dowod | Prywatny obraz dowodu zakupu |
| /opinia | Wystawienie albo edycja oceny |
| /profil | Reputacja sprzedawcy |
| /ranking | Ranking z progiem różnych oceniających |
| /kolejka | Lista spraw oczekujących na personel |
| /rozstrzygnij | Zamknięcie sporu z uzasadnieniem |
| /ukryj_opinie | Moderacja widoczności opinii z audytem |
| /odpowiedz | Publiczna odpowiedź sprzedawcy na opinię |
| /moderuj | Ostrzeżenie / timeout / zdjęcie timeoutu |
| /wyczysc | Usuwanie wiadomości z kanałów społeczności |
| /statystyki | Liczby rekordów i opóźnienie połączenia |
| /diagnostyka | Brakujące role, kanały i niedokończone publikacje |
| /historia | Eksport bieżącego kanału zgłoszenia lub zamówienia |
| /backup | Właściciel: pobranie bazy |

## 13. Kopie, aktualizacje i odtwarzanie

**Najważniejszy plik:** `data/hub.sqlite3`. Zawiera identyfikatory kanałów, role, oferty, zamówienia, opinie i decyzje. Bez niego bot nie rozpozna starej konfiguracji. Nie usuwaj folderu data przy aktualizacji kodu.

Bot wykonuje kopię przy konserwacji co godzinę, nadpisując dzienny plik w `data/backups`. Zachowuje siedem ostatnich dni, w których utworzono kopię. /backup umożliwia pobranie bieżącej spójnej kopii. Kopie na tym samym hostingu nie zastępują własnej kopii poza nim.

**Aktualizacja:** pobierz /backup → zatrzymaj bota → podmień kod i requirements.txt → pozostaw data, sekrety oraz config.json → uruchom → /diagnostyka. Nie uruchamiaj równocześnie dwóch kopii tej paczki na tym samym tokenie i bazie.

**Odtworzenie:** zatrzymaj bota → zachowaj obecny folder data jako kopię → umieść pobraną kopię pod nazwą `data/hub.sqlite3` w nowym pustym folderze danych → uruchom z tym samym GUILD_ID. Nie łącz przywracanej kopii ze starymi plikami `hub.sqlite3-wal` i `hub.sqlite3-shm`. Odtworzenie bazy nie odtworzy wiadomości lub kanałów wcześniej usuniętych z Discorda.

**Archiwum kanałów:** nie jest automatycznie kasowane. Po potrzebnym okresie przechowywania pobierz /historia i dopiero potem usuń dany kanał ręcznie. Eksport obejmuje maksymalnie pierwsze 2000 istniejących wiadomości. Usuniętych wersji wiadomości nie odzyskuje, a linki do załączników mogą wygasać.

## 14. Ustawienia i personalizacja

Nie potrzebujesz config.json do podstawowego startu: wystarczą DISCORD_TOKEN i GUILD_ID w środowisku. Aby zmienić limity, skopiuj config.example.json jako config.json i popraw wartości.

| Ustawienie | Domyślnie | Znaczenie |
|---|---|---|
| guild_id | 0 | Serwer; GUILD_ID w środowisku ma pierwszeństwo |
| data_dir | data | Katalog bazy i kopii |
| max_offers_per_seller | 10 | Limit otwartych ofert sprzedawcy |
| max_open_orders_per_buyer | 3 | Limit aktywnych zamówień kupującego |
| proof_retention_days | 30 | Retencja rozpatrzonych obrazów dowodów |
| reminder_hours | 48 | Odstęp zbiorczych przypomnień dla personelu |

Nazwy ról i kanałów zmieniasz w `hub/setup.py` przed pierwszą konfiguracją. Istniejące nazwy możesz zmienić ręcznie na Discordzie — bot używa zapisanych identyfikatorów. Wygląd wiadomości i podstawowy regulamin znajdują się w `hub/client.py`. Po zmianie treści paneli restartuj i użyj /panele.

Nie zmieniaj samodzielnie prefiksów `hub:` w identyfikatorach przycisków. Są potrzebne do obsługi wiadomości po restarcie.

## 15. Najczęstsze problemy

| Objaw | Co zrobić |
|---|---|
| Brak DISCORD_TOKEN | Dodaj zmienną sekretną albo popraw nazwę .env |
| Brak GUILD_ID / błędna liczba | Skopiuj ID serwera; nie wpisuj nazwy, linku ani Application ID |
| LoginFailure / token invalid | Wygeneruj nowy token bota, podmień sekret i restartuj |
| PrivilegedIntentsRequired / kod 4014 | Włącz Message Content Intent w Bot → Privileged Gateway Intents |
| Bot online, brak komend | Sprawdź GUILD_ID, obecność bota na tym serwerze i zakres applications.commands; ponownie otwórz Discorda |
| /konfiguruj wymaga Community | Dokończ kreator Społeczności w ustawieniach serwera |
| Missing Permissions / 403 | Sprawdź uprawnienia bota, nadpisania kanału i kolejność ról |
| Rola nie może być nadana | Rola bota musi być wyżej niż nadawana rola; personel nie może być nad botem, jeśli bot ma go moderować |
| Brak discord / ModuleNotFoundError | Hosting musi zainstalować requirements.txt w tym samym katalogu co main.py |
| Can't open file main.py | Rozpakuj ZIP i popraw Entry File; sprawdź dodatkowy folder po rozpakowaniu |
| Ofertę zapisano, ale nie ma posta | /diagnostyka, następnie /oferta → Ponów publikację |
| Zamówienie utknęło w tworzeniu | Przywróć uprawnienia/miejsce w kategorii, kliknij Kup ponownie; nie płać drugi raz |
| Formularz po restarcie nie działa | Otwórz go ponownie z przycisku; sam formularz jest tymczasowy |
| Nie ma powiadomienia na DM | Sprawdź blokady DM; stan zamówienia nadal sprawdzisz przez /moje |
| OOM / memory limit | Sprawdź RAM; 256 MB może nie wystarczyć przy wzroście ruchu. Zmniejsz obciążenie lub przenieś bota z kopią danych |
| Hosting zawieszony | Sprawdź ręczne odnowienie planu Free co 4 dni |
| Utracono reputację po podmianie plików | Sprawdź katalog danych i przywróć kopię SQLite; nie twórz nowej konfiguracji na pustej bazie |

## 16. Uruchomienie na komputerze zamiast hostingu

Zainstaluj Python 3.12, rozpakuj paczkę i otwórz terminal w jej folderze:

```bash
python -m venv .venv
```

Windows:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Linux / macOS:

```bash
.venv/bin/python -m pip install -r requirements.txt
cp .env.example .env
```

Wpisz token i ID do `.env`, następnie uruchom odpowiednio:

```powershell
.venv\Scripts\python.exe main.py
```

lub:

```bash
.venv/bin/python main.py
```

Bot pozostaje dostępny, gdy proces działa i komputer ma internet. Po zamknięciu procesu lub uśpieniu urządzenia przestaje obsługiwać przyciski. Oferty i kanały już utworzone na Discordzie pozostają.
