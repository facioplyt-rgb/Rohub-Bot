"""SQLite: reguły transakcji są niezależne od Discorda i testowane lokalnie.

Jedna instancja procesu. Operacje nie zawierają await; ograniczenia UNIQUE
chronią również przed ponownym kliknięciem i ponownym uruchomieniem.
"""
import json
import sqlite3
import time
from pathlib import Path


class RuleError(Exception):
    pass


class Store:
    TABLES = {'offers', 'orders', 'proofs', 'reviews', 'tickets'}

    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, timeout=10)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript('''
        PRAGMA foreign_keys=ON;
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS settings(guild INTEGER PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS offers(
            id INTEGER PRIMARY KEY, guild INTEGER NOT NULL, seller INTEGER NOT NULL,
            title TEXT NOT NULL, category TEXT NOT NULL, details TEXT NOT NULL,
            status TEXT NOT NULL, official INTEGER NOT NULL DEFAULT 0,
            requested INTEGER NOT NULL DEFAULT 0, version INTEGER NOT NULL DEFAULT 1,
            thread INTEGER, message INTEGER, checked_by INTEGER,
            checked_at INTEGER, check_note TEXT, created INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS orders(
            id INTEGER PRIMARY KEY, guild INTEGER NOT NULL, offer INTEGER NOT NULL REFERENCES offers(id),
            buyer INTEGER NOT NULL, seller INTEGER NOT NULL, snapshot TEXT NOT NULL,
            state TEXT NOT NULL DEFAULT 'creating', channel INTEGER,
            delivered INTEGER NOT NULL DEFAULT 0, received INTEGER NOT NULL DEFAULT 0,
            proof_status TEXT NOT NULL DEFAULT 'none', proof_id INTEGER,
            created INTEGER NOT NULL, updated INTEGER NOT NULL);
        CREATE UNIQUE INDEX IF NOT EXISTS one_open_order ON orders(guild,offer,buyer)
            WHERE state IN ('creating','open','disputed');
        CREATE TABLE IF NOT EXISTS proofs(
            id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id),
            description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
            staff_message INTEGER, reviewer INTEGER, reason TEXT,
            created INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS reviews(
            id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL UNIQUE REFERENCES orders(id),
            guild INTEGER NOT NULL, seller INTEGER NOT NULL, buyer INTEGER NOT NULL,
            rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
            delivered INTEGER NOT NULL, matches INTEGER NOT NULL, comment TEXT NOT NULL,
            hidden INTEGER NOT NULL DEFAULT 0, message INTEGER, updated INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(
            id INTEGER PRIMARY KEY, guild INTEGER NOT NULL, actor INTEGER NOT NULL,
            action TEXT NOT NULL, data TEXT NOT NULL, created INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS watches(
            guild INTEGER NOT NULL, user INTEGER NOT NULL, offer INTEGER NOT NULL,
            PRIMARY KEY(guild,user,offer));
        CREATE TABLE IF NOT EXISTS tickets(
            id INTEGER PRIMARY KEY, guild INTEGER NOT NULL, user INTEGER NOT NULL,
            subject TEXT NOT NULL, channel INTEGER, state TEXT NOT NULL DEFAULT 'open',
            created INTEGER NOT NULL);
        ''')

    @staticmethod
    def decode(row):
        if row is None:
            return None
        item = dict(row)
        for key in ('details', 'snapshot'):
            if key in item:
                item[key] = json.loads(item[key])
        return item

    def one(self, sql, args=()):
        return self.decode(self.conn.execute(sql, args).fetchone())

    def rows(self, sql, args=()):
        return [self.decode(row) for row in self.conn.execute(sql, args).fetchall()]

    def get(self, table, ident):
        if table not in self.TABLES:
            raise ValueError('Nieznana tabela')
        result = self.one(f'SELECT * FROM {table} WHERE id=?', (ident,))
        if not result:
            raise RuleError('Nie znaleziono rekordu. Sprawdź numer.')
        return result

    def execute(self, sql, args=()):
        with self.conn:
            return self.conn.execute(sql, args)

    def audit(self, guild, actor, action, data):
        self.execute('INSERT INTO audit(guild,actor,action,data,created) VALUES(?,?,?,?,?)',
                     (guild, actor, action, json.dumps(data, ensure_ascii=False), int(time.time())))

    def config(self, guild):
        row = self.conn.execute('SELECT value FROM settings WHERE guild=?', (guild,)).fetchone()
        return json.loads(row[0]) if row else {}

    def save_config(self, guild, value):
        self.execute('INSERT INTO settings VALUES(?,?) ON CONFLICT(guild) DO UPDATE SET value=excluded.value',
                     (guild, json.dumps(value)))

    def create_offer(self, guild, seller, title, category, details, official, limit=10):
        if category not in ('modele', 'mapy', 'skrypty', 'zestawy', 'uslugi'):
            raise RuleError('Nieprawidłowa kategoria.')
        count = self.one("SELECT COUNT(*) AS n FROM offers WHERE guild=? AND seller=? AND status!='rejected'", (guild, seller))['n']
        if count >= limit:
            raise RuleError('Osiągnięto limit ofert. Zamknij starą ofertę lub poproś administrację.')
        cur = self.execute('''INSERT INTO offers(guild,seller,title,category,details,status,requested,created)
            VALUES(?,?,?,?,?,?,?,?)''', (guild, seller, title, category, json.dumps(details, ensure_ascii=False),
                                      'pending' if official else 'publishing', int(official), int(time.time())))
        return cur.lastrowid

    def publish_offer(self, ident, thread, message):
        self.execute("UPDATE offers SET thread=?,message=?,status='active' WHERE id=? AND status='publishing'",
                     (thread, message, ident))

    def decide_offer(self, ident, actor, approved, reason):
        offer = self.get('offers', ident)
        if actor == offer['seller']:
            raise RuleError('Własną ofertę musi sprawdzić inna osoba.')
        if offer['status'] != 'pending':
            raise RuleError('Oferta nie czeka na taką decyzję.')
        self.execute('''UPDATE offers SET status=?,official=?,checked_by=?,checked_at=?,check_note=? WHERE id=?''',
                     ('publishing' if approved else 'rejected', int(approved), actor, int(time.time()), reason, ident))
        self.audit(offer['guild'], actor, 'offer_decision', {'offer': ident, 'approved': approved, 'reason': reason})

    def update_offer(self, ident, actor, details, staff):
        offer = self.get('offers', ident)
        if actor != offer['seller'] and not staff:
            raise RuleError('To nie jest Twoja oferta.')
        merged = dict(offer['details'])
        merged.update(details)
        must_check = bool(offer['official'] or offer['requested'])
        self.execute('''UPDATE offers SET details=?,version=version+1,official=0,status=? WHERE id=?''',
                     (json.dumps(merged, ensure_ascii=False), 'pending' if must_check else 'publishing', ident))
        self.audit(offer['guild'], actor, 'offer_edit', {'offer': ident, 'old': offer['details'], 'new': merged})

    def reserve_order(self, guild, offer_id, buyer, limit):
        offer = self.get('offers', offer_id)
        if offer['guild'] != guild or offer['status'] != 'active':
            raise RuleError('Oferta nie jest dostępna na tym serwerze.')
        if buyer == offer['seller']:
            raise RuleError('Nie możesz kupić własnej oferty.')
        existing = self.one("SELECT * FROM orders WHERE guild=? AND offer=? AND buyer=? AND state IN ('creating','open','disputed')",
                            (guild, offer_id, buyer))
        if existing:
            return existing, False
        count = self.one("SELECT COUNT(*) AS n FROM orders WHERE guild=? AND buyer=? AND state IN ('creating','open','disputed')", (guild, buyer))['n']
        if count >= limit:
            raise RuleError('Masz już maksymalną liczbę aktywnych zamówień.')
        now = int(time.time())
        cur = self.execute('''INSERT INTO orders(guild,offer,buyer,seller,snapshot,created,updated)
            VALUES(?,?,?,?,?,?,?)''', (guild, offer_id, buyer, offer['seller'], json.dumps(offer, ensure_ascii=False), now, now))
        return self.get('orders', cur.lastrowid), True

    def set_order_channel(self, ident, channel):
        self.execute("UPDATE orders SET channel=?,state='open',updated=? WHERE id=? AND state='creating'",
                     (channel, int(time.time()), ident))

    def order_action(self, ident, actor, action, staff=False):
        order = self.get('orders', ident)
        if actor not in (order['buyer'], order['seller']) and not staff:
            raise RuleError('Nie masz dostępu do tego zamówienia.')
        if order['state'] in ('archived', 'cancelled', 'failed'):
            raise RuleError('To zamówienie jest już zamknięte.')
        if action == 'delivered':
            if actor != order['seller']:
                raise RuleError('Dostawę oznacza sprzedawca.')
            self.execute('UPDATE orders SET delivered=1,updated=? WHERE id=?', (int(time.time()), ident))
        elif action == 'received':
            if actor != order['buyer']:
                raise RuleError('Odbiór potwierdza kupujący.')
            self.execute('UPDATE orders SET received=1,updated=? WHERE id=?', (int(time.time()), ident))
        elif action == 'dispute':
            self.execute("UPDATE orders SET state='disputed',updated=? WHERE id=?", (int(time.time()), ident))
        elif action == 'resolve':
            if not staff or actor in (order['buyer'], order['seller']):
                raise RuleError('Spór rozstrzyga niezależny opiekun transakcji.')
            self.execute("UPDATE orders SET state='open',updated=? WHERE id=?", (int(time.time()), ident))
        elif action == 'cancel':
            needs_independent_staff = (actor != order['buyer'] or order['delivered'] or order['received']
                                       or order['state'] == 'disputed' or order['proof_status'] in ('pending', 'approved'))
            if needs_independent_staff and (not staff or actor in (order['buyer'], order['seller'])):
                raise RuleError('Po dostawie lub otwarciu sporu zamówienie może anulować administracja.')
            self.execute("UPDATE orders SET state='cancelled',updated=? WHERE id=?", (int(time.time()), ident))
        elif action == 'archive':
            if not staff or actor in (order['buyer'], order['seller']) or order['state'] == 'disputed':
                raise RuleError('Archiwizuje niezależny opiekun po zakończeniu sporu.')
            if order['proof_status'] != 'approved':
                raise RuleError('Najpierw rozpatrz dowód. Porzucone zamówienie można anulować zamiast archiwizować jako zakończone.')
            self.execute("UPDATE orders SET state='archived',updated=? WHERE id=?", (int(time.time()), ident))
        else:
            raise RuleError('Nieznana czynność.')
        self.audit(order['guild'], actor, 'order_' + action, {'order': ident})

    def submit_proof(self, ident, actor, description):
        order = self.get('orders', ident)
        if actor != order['buyer']:
            raise RuleError('Dowód przesyła kupujący.')
        if order['state'] not in ('open', 'disputed'):
            raise RuleError('Zamówienie nie jest aktywne.')
        if order['proof_status'] in ('pending', 'approved'):
            raise RuleError('Dowód już czeka na decyzję albo został zatwierdzony.')
        with self.conn:
            cur = self.conn.execute('INSERT INTO proofs(order_id,description,created) VALUES(?,?,?)', (ident, description, int(time.time())))
            self.conn.execute("UPDATE orders SET proof_status='pending',proof_id=? WHERE id=?", (cur.lastrowid, ident))
        return cur.lastrowid

    def decide_proof(self, proof_id, actor, approved, reason):
        proof = self.get('proofs', proof_id)
        order = self.get('orders', proof['order_id'])
        if actor in (order['buyer'], order['seller']):
            raise RuleError('Własną transakcję musi sprawdzić inny opiekun.')
        if order['proof_id'] != proof_id or proof['status'] != 'pending':
            raise RuleError('Ten dowód został już rozpatrzony albo zastąpiony.')
        if order['state'] not in ('open', 'disputed'):
            raise RuleError('Zamówienie jest zamknięte.')
        status = 'approved' if approved else 'rejected'
        with self.conn:
            self.conn.execute('UPDATE proofs SET status=?,reviewer=?,reason=? WHERE id=?', (status, actor, reason, proof_id))
            self.conn.execute('UPDATE orders SET proof_status=? WHERE id=?', (status, order['id']))
        self.audit(order['guild'], actor, 'proof_decision', {'proof': proof_id, 'status': status, 'reason': reason})

    def review(self, ident, actor, rating, delivered, matches, comment):
        order = self.get('orders', ident)
        if actor != order['buyer'] or order['proof_status'] != 'approved':
            raise RuleError('Opinię wystawia kupujący po zatwierdzeniu dowodu.')
        if order['state'] in ('cancelled', 'failed', 'creating'):
            raise RuleError('Nie można ocenić tego zamówienia.')
        if not 1 <= rating <= 5:
            raise RuleError('Ocena musi wynosić od 1 do 5.')
        old = self.one('SELECT * FROM reviews WHERE order_id=?', (ident,))
        if old and old['hidden']:
            raise RuleError('Opinia jest ukryta przez administrację. Użyj zgłoszenia, aby się odwołać.')
        self.execute('''INSERT INTO reviews(order_id,guild,seller,buyer,rating,delivered,matches,comment,updated)
            VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(order_id) DO UPDATE SET rating=excluded.rating,
            delivered=excluded.delivered,matches=excluded.matches,comment=excluded.comment,updated=excluded.updated''',
                     (ident, order['guild'], order['seller'], actor, rating, int(delivered), int(matches), comment, int(time.time())))
        self.audit(order['guild'], actor, 'review_edit' if old else 'review_create', {'order': ident, 'old': old, 'rating': rating, 'comment': comment})
        return self.one('SELECT * FROM reviews WHERE order_id=?', (ident,))

    def profile(self, guild, seller):
        stats = self.one('''SELECT COUNT(*) AS reviews, COUNT(DISTINCT buyer) AS buyers,
            ROUND(AVG(rating),2) AS average FROM reviews WHERE guild=? AND seller=? AND hidden=0''', (guild, seller))
        stats['transactions'] = self.one("SELECT COUNT(*) AS n FROM orders WHERE guild=? AND seller=? AND proof_status='approved' AND state NOT IN ('cancelled','failed','creating')", (guild, seller))['n']
        stats['offers'] = self.one("SELECT COUNT(*) AS n FROM offers WHERE guild=? AND seller=? AND status='active'", (guild, seller))['n']
        return stats

    def backup(self, target):
        target = Path(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(target) as other:
            self.conn.backup(other)

    def close(self):
        self.conn.close()
